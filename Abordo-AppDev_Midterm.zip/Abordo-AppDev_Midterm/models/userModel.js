// In-memory user database (mock)
const users = [];

// Add a user to the in-memory users array
const addUser = (user) => {
  users.push(user);
};

// Retrieve a user by username
const getUserByUsername = (username) => {
  return users.find((user) => user.username === username);
};

// Retrieve a user by ID
const getUserById = (id) => {
  return users.find((user) => user.id === id);
};

module.exports = {
  users,
  addUser,
  getUserByUsername,
  getUserById,
};
