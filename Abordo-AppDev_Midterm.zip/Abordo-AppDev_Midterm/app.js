const express = require('express');
const userRoutes = require('./routes/user');

const app = express();

app.use(express.json());  // JSON parser middleware

// Root route
app.get('/', (req, res) => {
    res.send('Hi sir, this is my API');
});

// Use user routes for /user
app.use('/user', userRoutes);

// Global error handler
app.use((err, req, res, next) => {
    console.error('Error stack: ', err.stack);
    res.status(500).send('Internal server error');
});

// Server setup
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
